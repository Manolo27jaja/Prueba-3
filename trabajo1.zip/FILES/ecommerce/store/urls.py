from django.urls import path

from . import views

from django.conf import settings
from django.contrib.staticfiles.urls import static


urlpatterns = [
	#Leave as empty string for base url
	path('', views.store, name="store"),
	path('cart/', views.cart, name="cart"),
	path('checkout/', views.checkout, name="checkout"),
	path('editar', views.editar, name="editar"),
	path('agregar', views.agregar, name="agregar"),
	path('cli_agregar', views.cli_agregar, name="cli_agregar"),
	path('index', views.index, name="index"),
	path('form', views.form, name="form"),
	path('update_item/', views.updateItem, name="update_item"),
	path('cliente', views.cliente, name="cliente"),
]

static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)