from django.shortcuts import render
from django.http import JsonResponse

import json
from .models import * 
from .forms import ProductForm
from .forms import CustomerForm


def editar(request):
	return render(request, 'panel/editar.html')


def cliente(request):
	customers=Customer.objects.all()
	datos={'customers': customers}
	return render(request, 'panel/cliente.html', datos)

def agregar(request):
    datos = {"form":ProductForm()}
    if request.method == "POST":
        form = ProductForm(request.POST)
        if form.is_valid:
            form.save()
            datos["mensaje"] = "Producto agregado!."
    return render(request, 'panel/agregar.html', datos)


def cli_agregar(request):
    datos = {"form":CustomerForm()}
    if request.method == "POST":
        form = CustomerForm(data=request.POST, files=request.FILES)
        if form.is_valid:
            form.save()
            datos["mensaje"] = "C agregado!."
    return render(request, 'panel/cli_agregar.html', datos)




def index(request):
	products=Product.objects.all()
	datos={'products': products}
	return render(request, 'panel/index.html', datos)




def form(request):
	return render(request, 'admin/form.html')




def store(request):

	if request.user.is_authenticated:
		customer = request.user.customer
		order, created = Order.objects.get_or_create(customer=customer, complete=False)
		items = order.orderitem_set.all()
		cartItems = order.get_cart_items
	else:
		#Create empty cart for now for non-logged in user
		items = []
		order = {'get_cart_total':0, 'get_cart_items':0, 'shipping':False}
		cartItems = order['get_cart_items']

	products = Product.objects.all()
	context = {'products':products, 'cartItems':cartItems}
	return render(request, 'store/store.html', context)
def cart(request):

	if request.user.is_authenticated:
		customer = request.user.customer
		order, created = Order.objects.get_or_create(customer=customer, complete=False)
		items = order.orderitem_set.all()

	else:
		items = []
		order = {'get_cart_total':0, 'get_cart_items':0}


	context = {'items':items, 'order':order}
	return render(request, 'store/cart.html', context)





def checkout(request):
	if request.user.is_authenticated:
		customer = request.user.customer
		order, created = Order.objects.get_or_create(customer=customer, complete=False)
		items = order.orderitem_set.all()
	else:
		#Create empty cart for now for non-logged in user
		items = []
		order = {'get_cart_total':0, 'get_cart_items':0}


	context = {'items':items, 'order':order}
	return render(request, 'store/checkout.html', context)




	
def updateItem(request):
	data = json.loads(request.body)
	productId = data['productId']
	action = data['action']

	
	print('Action:', action)
	print('ProductId:', productId)


	customer = request.user.customer
	product = Product.objects.get(id=productId)
	order, created = Order.objects.get_or_create(customer=customer, complete=False)

	orderItem, created = OrderItem.objects.get_or_create(order=order, product=product)

	if action == 'add':
		orderItem.quantity = (orderItem.quantity + 1)
	elif action == 'remove':
		orderItem.quantity = (orderItem.quantity - 1)

	orderItem.save()

	if orderItem.quantity <= 0:
		orderItem.delete()


	return JsonResponse('Item was added', safe=False) 